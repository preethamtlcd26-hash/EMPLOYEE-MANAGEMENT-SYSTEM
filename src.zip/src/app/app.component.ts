import { Component, OnInit } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, MatToolbarModule, MatButtonModule, MatIconModule],
  template: `
    <mat-toolbar color="primary">
      <span>Employee Management</span>
      <span class="spacer"></span>
      <a mat-button routerLink="/home">Home</a>
      <a mat-button routerLink="/employees">Employees</a>
      <a mat-button routerLink="/employees/add">Add Employee</a>

      <button mat-icon-button
              type="button"
              (click)="toggleDarkMode()"
              [attr.aria-label]="darkMode ? 'Switch to light mode' : 'Switch to dark mode'">
        <mat-icon>{{ darkMode ? 'light_mode' : 'dark_mode' }}</mat-icon>
      </button>
    </mat-toolbar>

    <main class="container">
      <router-outlet></router-outlet>
    </main>
  `,
  styles: [`
    .spacer { flex: 1 1 auto; }
    .container { padding: 24px; max-width: 1100px; margin: auto; }
    a { color: white; text-decoration: none; }
  `]
})
export class AppComponent implements OnInit {

  darkMode = false;

  ngOnInit(): void {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem('darkMode');
    } catch { /* storage not available */ }

    this.darkMode = saved !== null
      ? saved === 'true'
      : window.matchMedia('(prefers-color-scheme: dark)').matches;

    this.applyTheme();
  }

  toggleDarkMode(): void {
    this.darkMode = !this.darkMode;
    this.applyTheme();
    try {
      localStorage.setItem('darkMode', String(this.darkMode));
    } catch { /* ignore */ }
  }

  private applyTheme(): void {
    // The class goes on <body> so dialogs and snackbars (which live outside
    // <app-root>) are themed too.
    document.body.classList.toggle('dark-theme', this.darkMode);
  }
}