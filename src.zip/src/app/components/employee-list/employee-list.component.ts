import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';
import { EmployeeService } from '../../services/employee.service';
import { DEPARTMENTS, Employee, yearsOfService } from '../../models/employee';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ConfirmDialogComponent } from '../confirm-dialog/confirm-dialog.component';
import { EmployeeDetailsDialogComponent } from '../employee-details-dialog/employee-details-dialog.component';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    MatTableModule,
    MatSortModule,
    MatPaginatorModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatProgressBarModule,
    MatSnackBarModule,
    MatDialogModule
  ],
  template: `
    <mat-card>
      <mat-progress-bar *ngIf="loading" mode="indeterminate"></mat-progress-bar>

      <mat-card-header>
        <mat-card-title>Employee List</mat-card-title>
      </mat-card-header>

      <mat-card-content>

        <!-- Filters -->
        <div class="filters">
          <mat-form-field appearance="outline" class="search-field">
            <mat-label>Search by name</mat-label>
            <input matInput
                   [ngModel]="search"
                   (ngModelChange)="search = $event; applyFilters()"
                   placeholder="Type a name...">
            <mat-icon matSuffix *ngIf="!search">search</mat-icon>
            <button matSuffix mat-icon-button type="button" *ngIf="search"
                    aria-label="Clear search"
                    (click)="search = ''; applyFilters()">
              <mat-icon>close</mat-icon>
            </button>
          </mat-form-field>

          <mat-form-field appearance="outline" class="small-field">
            <mat-label>Department</mat-label>
            <mat-select [ngModel]="department"
                        (ngModelChange)="department = $event; applyFilters()">
              <mat-option value="">All</mat-option>
              <mat-option *ngFor="let d of departments" [value]="d">{{ d }}</mat-option>
            </mat-select>
          </mat-form-field>

          <mat-form-field appearance="outline" class="small-field">
            <mat-label>Min salary</mat-label>
            <input matInput type="number" min="0"
                   [ngModel]="minSalary"
                   (ngModelChange)="minSalary = $event; applyFilters()">
          </mat-form-field>

          <mat-form-field appearance="outline" class="small-field">
            <mat-label>Max salary</mat-label>
            <input matInput type="number" min="0"
                   [ngModel]="maxSalary"
                   (ngModelChange)="maxSalary = $event; applyFilters()">
          </mat-form-field>

          <button mat-button type="button" *ngIf="hasActiveFilters" (click)="clearFilters()">
            <mat-icon>filter_alt_off</mat-icon>
            Clear filters
          </button>
        </div>

        <!-- Actions -->
        <div class="actions">
          <a mat-raised-button color="primary" routerLink="/employees/add">
            <mat-icon>add</mat-icon>
            Add Employee
          </a>

          <button mat-stroked-button type="button" (click)="exportCsv()">
            <mat-icon>download</mat-icon>
            Export CSV
          </button>

          <button mat-stroked-button type="button" (click)="printList()">
            <mat-icon>print</mat-icon>
            Print
          </button>

          <button mat-raised-button color="warn" type="button"
                  *ngIf="selection.selected.length > 0"
                  (click)="deleteSelected()">
            <mat-icon>delete</mat-icon>
            Delete selected ({{ selection.selected.length }})
          </button>
        </div>

        <!-- Summary line -->
        <div class="summary">
          <span>
            Showing <strong>{{ dataSource.filteredData.length }}</strong>
            of <strong>{{ dataSource.data.length }}</strong> employees
          </span>

          <span class="updated" *ngIf="lastUpdated">
            Last updated: {{ lastUpdated | date:'mediumTime' }}
          </span>

          <button mat-icon-button type="button" matTooltip="Refresh"
                  aria-label="Refresh" [disabled]="loading" (click)="loadEmployees()">
            <mat-icon>refresh</mat-icon>
          </button>
        </div>

        <div *ngIf="!loading && dataSource.data.length === 0" class="empty">
          No employees found.
        </div>

        <div *ngIf="!loading && dataSource.data.length > 0 && dataSource.filteredData.length === 0"
             class="empty">
          No employees match your filters.
        </div>

        <!-- Always rendered (just hidden) so MatSort/MatPaginator can attach -->
        <div class="table-wrap" [hidden]="dataSource.filteredData.length === 0">
          <table mat-table [dataSource]="dataSource" matSort
                 matSortActive="createdAt" matSortDirection="desc">

            <ng-container matColumnDef="select">
              <th mat-header-cell *matHeaderCellDef>
                <mat-checkbox
                  (change)="toggleAll()"
                  [checked]="isAllSelected()"
                  [indeterminate]="selection.hasValue() && !isAllSelected()"
                  aria-label="Select all">
                </mat-checkbox>
              </th>
              <td mat-cell *matCellDef="let employee" (click)="$event.stopPropagation()">
                <mat-checkbox
                  (change)="selection.toggle(employee)"
                  [checked]="selection.isSelected(employee)"
                  aria-label="Select row">
                </mat-checkbox>
              </td>
            </ng-container>

            <ng-container matColumnDef="employeeId">
              <th mat-header-cell *matHeaderCellDef mat-sort-header>ID</th>
              <td mat-cell *matCellDef="let employee">{{ employee.employeeId }}</td>
            </ng-container>

            <ng-container matColumnDef="ename">
              <th mat-header-cell *matHeaderCellDef mat-sort-header>Name</th>
              <td mat-cell *matCellDef="let employee">
                {{ employee.ename }}
                <mat-icon *ngIf="isTopEarner(employee)"
                          class="top-icon"
                          matTooltip="Highest paid"
                          aria-label="Highest paid">star</mat-icon>
              </td>
            </ng-container>

            <ng-container matColumnDef="department">
              <th mat-header-cell *matHeaderCellDef mat-sort-header>Department</th>
              <td mat-cell *matCellDef="let employee">{{ employee.department || '—' }}</td>
            </ng-container>

            <ng-container matColumnDef="salary">
              <th mat-header-cell *matHeaderCellDef mat-sort-header>Salary</th>
              <td mat-cell *matCellDef="let employee">
                {{ employee.salary | currency:'INR':'symbol':'1.2-2' }}
              </td>
            </ng-container>

            <ng-container matColumnDef="joiningDate">
              <th mat-header-cell *matHeaderCellDef mat-sort-header>Joined</th>
              <td mat-cell *matCellDef="let employee">
                <ng-container *ngIf="employee.joiningDate; else noDate">
                  {{ employee.joiningDate | date:'dd MMM yyyy' }}
                  <div class="muted">{{ years(employee) }}</div>
                </ng-container>
                <ng-template #noDate>—</ng-template>
              </td>
            </ng-container>

            <ng-container matColumnDef="createdAt">
              <th mat-header-cell *matHeaderCellDef mat-sort-header>Added</th>
              <td mat-cell *matCellDef="let employee">
                {{ employee.createdAt ? (employee.createdAt | date:'dd MMM yyyy') : '—' }}
              </td>
            </ng-container>

            <ng-container matColumnDef="actions">
              <th mat-header-cell *matHeaderCellDef>Actions</th>
              <td mat-cell *matCellDef="let employee" (click)="$event.stopPropagation()">
                <a mat-raised-button
                   color="accent"
                   [routerLink]="['/employees/edit', employee.employeeId]">
                  Edit
                </a>

                <button mat-raised-button
                        color="warn"
                        type="button"
                        (click)="deleteEmployee(employee)">
                  Delete
                </button>
              </td>
            </ng-container>

            <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
            <tr mat-row *matRowDef="let row; columns: displayedColumns"
                class="clickable-row"
                matTooltip="Click for details"
                matTooltipShowDelay="800"
                (click)="openDetails(row)"></tr>
          </table>
        </div>

        <mat-paginator
          [hidden]="dataSource.filteredData.length === 0"
          [pageSizeOptions]="[5, 10, 25, 50]"
          [pageSize]="5"
          showFirstLastButtons>
        </mat-paginator>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .filters {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 12px;
      margin-top: 15px;
    }
    .search-field { width: 260px; max-width: 100%; }
    .small-field { width: 150px; }
    .actions {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-bottom: 12px;
    }
    .summary {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 16px;
      margin-bottom: 8px;
    }
    .updated, .muted { opacity: 0.7; font-size: 13px; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; }
    th, td { padding: 10px 12px; }
    td button, td a { margin-right: 8px; }
    .clickable-row { cursor: pointer; }
    .clickable-row:hover { background: rgba(128, 128, 128, 0.12); }
    .top-icon {
      color: #f9a825;
      font-size: 18px;
      width: 18px;
      height: 18px;
      vertical-align: middle;
      margin-left: 4px;
    }
    .empty { padding: 25px; text-align: center; }
  `]
})
export class EmployeeListComponent implements OnInit, AfterViewInit {

  dataSource = new MatTableDataSource<Employee>([]);
  selection = new SelectionModel<Employee>(true, []);

  displayedColumns = [
    'select', 'employeeId', 'ename', 'department',
    'salary', 'joiningDate', 'createdAt', 'actions'
  ];

  departments = DEPARTMENTS;

  // filter values
  search = '';
  department = '';
  minSalary: number | null = null;
  maxSalary: number | null = null;

  loading = false;
  lastUpdated: Date | null = null;
  topSalary: number | null = null;

  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;

  constructor(
    private employeeService: EmployeeService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {
    // Name + department + salary range, all combined
    this.dataSource.filterPredicate = (employee, filterJson) => {
      const f = JSON.parse(filterJson);
      const salary = Number(employee.salary);

      if (f.name && !(employee.ename ?? '').toLowerCase().includes(f.name)) {
        return false;
      }
      if (f.department && employee.department !== f.department) {
        return false;
      }
      if (f.min != null && salary < f.min) {
        return false;
      }
      if (f.max != null && salary > f.max) {
        return false;
      }
      return true;
    };

    this.dataSource.sortingDataAccessor = (employee, column) => {
      switch (column) {
        case 'ename': return (employee.ename ?? '').toLowerCase();
        case 'department': return (employee.department ?? '').toLowerCase();
        case 'salary': return Number(employee.salary);
        case 'employeeId': return Number(employee.employeeId);
        case 'joiningDate': return employee.joiningDate ?? '';
        case 'createdAt':
          // older rows without a timestamp fall back to their id
          return employee.createdAt
            ? Date.parse(employee.createdAt.replace(/(\.\d{3})\d+/, '$1'))
            : Number(employee.employeeId);
        default: return '';
      }
    };
  }

  ngOnInit(): void {
    this.loadEmployees();
  }

  ngAfterViewInit(): void {
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
  }

  // ---------- filters ----------

  get hasActiveFilters(): boolean {
    return !!this.search || !!this.department ||
           this.minSalary !== null || this.maxSalary !== null;
  }

  applyFilters(): void {
    this.selection.clear();

    this.dataSource.filter = JSON.stringify({
      name: this.search.trim().toLowerCase(),
      department: this.department,
      min: this.minSalary === null || (this.minSalary as unknown) === '' ? null : Number(this.minSalary),
      max: this.maxSalary === null || (this.maxSalary as unknown) === '' ? null : Number(this.maxSalary)
    });

    this.dataSource.paginator?.firstPage();
  }

  clearFilters(): void {
    this.search = '';
    this.department = '';
    this.minSalary = null;
    this.maxSalary = null;
    this.applyFilters();
  }

  // ---------- loading ----------

  loadEmployees(): void {
    this.loading = true;

    this.employeeService.getEmployees().subscribe({
      next: (data) => {
        this.dataSource.data = data;
        this.selection.clear();
        this.topSalary = data.length
          ? Math.max(...data.map(e => Number(e.salary)))
          : null;
        this.lastUpdated = new Date();
        this.loading = false;
      },
      error: (error) => {
        console.error('Error loading employees', error);
        this.loading = false;
        this.snackBar.open(
          'Unable to load employees. Check that the Spring Boot server is running.',
          'Close',
          { duration: 6000 }
        );
      }
    });
  }

  // ---------- helpers for the template ----------

  isTopEarner(employee: Employee): boolean {
    return this.topSalary !== null && Number(employee.salary) === this.topSalary;
  }

  years(employee: Employee): string {
    return yearsOfService(employee.joiningDate);
  }

  // ---------- selection ----------

  isAllSelected(): boolean {
    const rows = this.dataSource.filteredData;
    return rows.length > 0 && this.selection.selected.length === rows.length;
  }

  toggleAll(): void {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      this.selection.select(...this.dataSource.filteredData);
    }
  }

  // ---------- details / delete ----------

  openDetails(employee: Employee): void {
    this.dialog.open(EmployeeDetailsDialogComponent, {
      width: '480px',
      data: employee
    });
  }

  deleteEmployee(employee: Employee): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'Delete employee',
        message: `Are you sure you want to delete ${employee.ename}? This cannot be undone.`,
        confirmText: 'Delete',
        cancelText: 'Cancel'
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (!confirmed) {
        return;
      }

      this.employeeService.deleteEmployee(employee.employeeId).subscribe({
        next: () => {
          this.snackBar.open('Employee deleted successfully.', 'OK', { duration: 3000 });
          this.loadEmployees();
        },
        error: (error) => {
          console.error('Delete error', error);
          this.snackBar.open('Unable to delete employee.', 'Close', { duration: 5000 });
        }
      });
    });
  }

  deleteSelected(): void {
    const selected = this.selection.selected;
    const count = selected.length;

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: '400px',
      data: {
        title: 'Delete selected employees',
        message: `Are you sure you want to delete ${count} employee${count === 1 ? '' : 's'}? This cannot be undone.`,
        confirmText: 'Delete',
        cancelText: 'Cancel'
      }
    });

    dialogRef.afterClosed().subscribe((confirmed: boolean) => {
      if (!confirmed) {
        return;
      }

      const ids = selected.map(e => e.employeeId);

      this.employeeService.deleteEmployees(ids).subscribe({
        next: () => {
          this.snackBar.open(`${count} employee${count === 1 ? '' : 's'} deleted.`, 'OK', { duration: 3000 });
          this.loadEmployees();
        },
        error: (error) => {
          console.error('Bulk delete error', error);
          this.snackBar.open('Unable to delete the selected employees.', 'Close', { duration: 5000 });
        }
      });
    });
  }

  // ---------- export / print ----------

  /** Rows currently matching the filters, in the current sort order. */
  private visibleRows(): Employee[] {
    const rows = this.dataSource.filteredData.slice();
    return this.sort ? this.dataSource.sortData(rows, this.sort) : rows;
  }

  exportCsv(): void {
    const rows = this.visibleRows();

    if (rows.length === 0) {
      this.snackBar.open('There are no employees to export.', 'OK', { duration: 3000 });
      return;
    }

    // Text cells starting with = + - @ could be run as formulas by Excel
    const text = (value: unknown): string => {
      let s = value === null || value === undefined ? '' : String(value);
      if (/^[=+\-@]/.test(s)) {
        s = "'" + s;
      }
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const raw = (value: unknown): string =>
      '"' + String(value ?? '').replace(/"/g, '""') + '"';

    const header = [
      'ID', 'Name', 'Department', 'Job Title', 'Gender', 'Email',
      'Phone', 'Salary', 'Joining Date', 'Years of Service', 'Added On'
    ];

    const lines = rows.map(e => [
      raw(e.employeeId),
      text(e.ename),
      text(e.department),
      text(e.jobTitle),
      text(e.gender),
      text(e.email),
      raw(e.phone),
      raw(e.salary),
      raw(e.joiningDate),
      raw(e.joiningDate ? yearsOfService(e.joiningDate) : ''),
      raw(e.createdAt ? e.createdAt.replace('T', ' ').substring(0, 19) : '')
    ].join(','));

    // The BOM makes Excel read the file as UTF-8
    const csv = '\uFEFF' + [header.map(h => '"' + h + '"').join(','), ...lines].join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `employees-${new Date().toISOString().substring(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  printList(): void {
    const rows = this.visibleRows();

    if (rows.length === 0) {
      this.snackBar.open('There are no employees to print.', 'OK', { duration: 3000 });
      return;
    }

    const esc = (value: unknown): string =>
      String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');

    const money = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' });

    const body = rows.map(e => `
      <tr>
        <td>${esc(e.employeeId)}</td>
        <td>${esc(e.ename)}</td>
        <td>${esc(e.department || '')}</td>
        <td>${esc(e.jobTitle || '')}</td>
        <td>${esc(e.email || '')}</td>
        <td>${esc(e.phone || '')}</td>
        <td class="num">${esc(money.format(Number(e.salary)))}</td>
        <td>${esc(e.joiningDate || '')}</td>
      </tr>`).join('');

    const html = `<!doctype html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Employee List</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 24px; color: #000; }
          h2 { margin: 0 0 4px; }
          p { margin: 0 0 16px; color: #555; }
          table { width: 100%; border-collapse: collapse; font-size: 13px; }
          th, td { border: 1px solid #999; padding: 6px 8px; text-align: left; }
          th { background: #eee; }
          .num { text-align: right; }
        </style>
      </head>
      <body>
        <h2>Employee List</h2>
        <p>${rows.length} employee${rows.length === 1 ? '' : 's'} &middot;
           printed ${esc(new Date().toLocaleString())}</p>
        <table>
          <thead>
            <tr>
              <th>ID</th><th>Name</th><th>Department</th><th>Job Title</th>
              <th>Email</th><th>Phone</th><th>Salary</th><th>Joined</th>
            </tr>
          </thead>
          <tbody>${body}</tbody>
        </table>
      </body>
      </html>`;

    // Print from a hidden iframe so the app's own page is not printed
    const iframe = document.createElement('iframe');
    iframe.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
    document.body.appendChild(iframe);

    const frameWindow = iframe.contentWindow;
    if (!frameWindow) {
      document.body.removeChild(iframe);
      return;
    }

    frameWindow.document.open();
    frameWindow.document.write(html);
    frameWindow.document.close();

    setTimeout(() => {
      frameWindow.focus();
      frameWindow.print();
      setTimeout(() => document.body.removeChild(iframe), 1000);
    }, 250);
  }
}