import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../models/employee';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink, MatButtonModule, MatIconModule],
  template: `
    <!-- ============ HERO ============ -->
    <section class="hero">
      <div class="hero-text">
        <span class="eyebrow">{{ greeting }}</span>
        <h1>Employee Management</h1>
        <p>Track your team, salaries and records in one place.</p>

        <div class="hero-actions">
          <a mat-flat-button class="btn-light" routerLink="/employees">
            <mat-icon>groups</mat-icon>
            View Employees
          </a>
          <a mat-stroked-button class="btn-outline" routerLink="/employees/add">
            <mat-icon>person_add</mat-icon>
            Add Employee
          </a>
        </div>
      </div>

      <div class="hero-art" aria-hidden="true">
        <span class="orb orb-1"></span>
        <span class="orb orb-2"></span>
        <mat-icon class="hero-icon">insights</mat-icon>
      </div>
    </section>

    <!-- ============ ERROR ============ -->
    <section class="error-card" *ngIf="error">
      <mat-icon>cloud_off</mat-icon>
      <div>
        <strong>Could not load the dashboard</strong>
        <p>Check that the Spring Boot server is running.</p>
      </div>
    </section>

    <!-- ============ LOADING SKELETONS ============ -->
    <section class="stats" *ngIf="loading">
      <div class="stat skeleton" *ngFor="let n of [1, 2, 3, 4]">
        <div class="sk sk-icon"></div>
        <div class="sk sk-line short"></div>
        <div class="sk sk-line big"></div>
      </div>
    </section>

    <!-- ============ STAT CARDS ============ -->
    <section class="stats" *ngIf="!loading && !error">

      <article class="stat c-indigo" style="--delay: 0ms">
        <div class="icon-tile"><mat-icon>groups</mat-icon></div>
        <div class="label">Total employees</div>
        <div class="value">{{ total }}</div>
        <div class="sub">People in the system</div>
      </article>

      <article class="stat c-teal" style="--delay: 80ms">
        <div class="icon-tile"><mat-icon>payments</mat-icon></div>
        <div class="label">Average salary</div>
        <div class="value">
          {{ total ? (average | currency:'INR':'symbol':'1.0-0') : '—' }}
        </div>
        <div class="sub">Across all employees</div>
      </article>

      <article class="stat c-amber" style="--delay: 160ms">
        <div class="icon-tile"><mat-icon>trending_up</mat-icon></div>
        <div class="label">Highest salary</div>
        <div class="value">
          {{ highest ? (highest.salary | currency:'INR':'symbol':'1.0-0') : '—' }}
        </div>
        <div class="sub" *ngIf="highest">
          <mat-icon class="mini">star</mat-icon>{{ highest.ename }}
        </div>
        <div class="sub" *ngIf="!highest">No data yet</div>
      </article>

      <article class="stat c-rose" style="--delay: 240ms">
        <div class="icon-tile"><mat-icon>trending_down</mat-icon></div>
        <div class="label">Lowest salary</div>
        <div class="value">
          {{ lowest ? (lowest.salary | currency:'INR':'symbol':'1.0-0') : '—' }}
        </div>
        <div class="sub" *ngIf="lowest">
          <mat-icon class="mini">person</mat-icon>{{ lowest.ename }}
        </div>
        <div class="sub" *ngIf="!lowest">No data yet</div>
      </article>
    </section>

    <!-- ============ SALARY RANGE ============ -->
    <section class="range-card" *ngIf="!loading && !error && total > 0" style="--delay: 320ms">
      <div class="range-head">
        <h2>Salary range</h2>
        <span>Lowest to highest, with the average marked</span>
      </div>

      <div class="track">
        <div class="track-fill"></div>
        <div class="marker" [style.left.%]="averagePercent">
          <span class="marker-dot"></span>
          <span class="marker-label">Avg</span>
        </div>
      </div>

      <div class="range-ends">
        <div>
          <small>Lowest</small>
          <strong>{{ lowest?.salary | currency:'INR':'symbol':'1.0-0' }}</strong>
        </div>
        <div class="end-right">
          <small>Highest</small>
          <strong>{{ highest?.salary | currency:'INR':'symbol':'1.0-0' }}</strong>
        </div>
      </div>
    </section>
  `,
  styles: [`
    :host { display: block; }

    /* ---------- hero ---------- */
    .hero {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 24px;
      overflow: hidden;
      padding: 36px 40px;
      border-radius: 24px;
      color: #fff;
      background: linear-gradient(120deg, #3f51b5 0%, #5c6bc0 45%, #8e24aa 100%);
      box-shadow: 0 12px 32px rgba(63, 81, 181, 0.35);
      animation: rise 0.5s ease both;
    }
    .hero-text { position: relative; z-index: 1; max-width: 520px; }
    .eyebrow {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.18);
      font-size: 13px;
      letter-spacing: 0.4px;
    }
    .hero h1 { margin: 14px 0 8px; font-size: 36px; font-weight: 600; line-height: 1.15; }
    .hero p { margin: 0 0 22px; opacity: 0.9; font-size: 16px; }
    .hero-actions { display: flex; flex-wrap: wrap; gap: 12px; }

    .btn-light { background: #fff !important; color: #3f51b5 !important; }
    .btn-outline {
      color: #fff !important;
      border-color: rgba(255, 255, 255, 0.7) !important;
    }
    .hero-actions mat-icon { margin-right: 6px; }

    .hero-art { position: relative; width: 180px; height: 150px; flex-shrink: 0; }
    .orb { position: absolute; border-radius: 50%; }
    .orb-1 {
      width: 150px; height: 150px; right: 0; top: -10px;
      background: rgba(255, 255, 255, 0.14);
    }
    .orb-2 {
      width: 90px; height: 90px; right: 90px; bottom: -10px;
      background: rgba(255, 255, 255, 0.1);
    }
    .hero-icon {
      position: absolute; right: 32px; top: 28px;
      font-size: 80px; width: 80px; height: 80px;
      opacity: 0.95;
    }

    /* ---------- stat cards ---------- */
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 18px;
      margin-top: 24px;
    }

    .stat {
      --accent: #3f51b5;
      --accent-2: #7986cb;
      position: relative;
      padding: 22px 22px 20px;
      border-radius: 20px;
      overflow: hidden;
      background: var(--mdc-elevated-card-container-color, #fff);
      border: 1px solid rgba(128, 128, 128, 0.18);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
      transition: transform 0.2s ease, box-shadow 0.2s ease;
      animation: rise 0.5s ease both;
      animation-delay: var(--delay, 0ms);
    }
    .stat::before {
      content: '';
      position: absolute; left: 0; top: 0; right: 0; height: 4px;
      background: linear-gradient(90deg, var(--accent), var(--accent-2));
    }
    .stat:hover {
      transform: translateY(-4px);
      box-shadow: 0 14px 28px rgba(0, 0, 0, 0.14);
    }

    .c-indigo { --accent: #3f51b5; --accent-2: #7986cb; }
    .c-teal   { --accent: #00897b; --accent-2: #4db6ac; }
    .c-amber  { --accent: #f9a825; --accent-2: #ffd54f; }
    .c-rose   { --accent: #e91e63; --accent-2: #f48fb1; }

    .icon-tile {
      display: grid;
      place-items: center;
      width: 48px; height: 48px;
      border-radius: 14px;
      color: #fff;
      background: linear-gradient(135deg, var(--accent), var(--accent-2));
      box-shadow: 0 6px 14px rgba(0, 0, 0, 0.18);
    }
    .icon-tile mat-icon { font-size: 26px; width: 26px; height: 26px; }

    .label { margin-top: 16px; font-size: 14px; opacity: 0.7; }
    .value {
      margin-top: 4px;
      font-size: 30px;
      font-weight: 600;
      letter-spacing: -0.5px;
      line-height: 1.2;
    }
    .sub {
      display: flex; align-items: center; gap: 4px;
      margin-top: 8px; font-size: 13px; opacity: 0.65;
    }
    .sub .mini { font-size: 16px; width: 16px; height: 16px; color: var(--accent); opacity: 1; }

    /* ---------- salary range ---------- */
    .range-card {
      margin-top: 24px;
      padding: 24px 26px 22px;
      border-radius: 20px;
      background: var(--mdc-elevated-card-container-color, #fff);
      border: 1px solid rgba(128, 128, 128, 0.18);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.06);
      animation: rise 0.5s ease both;
      animation-delay: var(--delay, 0ms);
    }
    .range-head { display: flex; flex-wrap: wrap; align-items: baseline; gap: 4px 14px; }
    .range-head h2 { margin: 0; font-size: 18px; font-weight: 600; }
    .range-head span { font-size: 13px; opacity: 0.65; }

    .track {
      position: relative;
      height: 12px;
      margin: 36px 8px 14px;
      border-radius: 999px;
      background: rgba(128, 128, 128, 0.2);
    }
    .track-fill {
      position: absolute; inset: 0;
      border-radius: 999px;
      background: linear-gradient(90deg, #e91e63, #f9a825 50%, #00897b);
    }
    .marker {
      position: absolute; top: 50%;
      transform: translateX(-50%);
      display: flex; flex-direction: column; align-items: center;
    }
    .marker-label {
      position: absolute; bottom: 22px;
      padding: 2px 10px;
      border-radius: 999px;
      font-size: 12px; font-weight: 600;
      color: #fff; background: #3f51b5;
    }
    .marker-dot {
      width: 22px; height: 22px;
      margin-top: -11px;
      border-radius: 50%;
      background: #fff;
      border: 4px solid #3f51b5;
      box-shadow: 0 3px 8px rgba(0, 0, 0, 0.3);
    }
    .range-ends { display: flex; justify-content: space-between; margin-top: 8px; }
    .range-ends small { display: block; font-size: 12px; opacity: 0.65; }
    .range-ends strong { font-size: 18px; }
    .end-right { text-align: right; }

    /* ---------- error ---------- */
    .error-card {
      display: flex; align-items: center; gap: 16px;
      margin-top: 24px; padding: 20px 24px;
      border-radius: 18px;
      color: #b71c1c; background: #ffebee;
      border: 1px solid #ffcdd2;
    }
    .error-card mat-icon { font-size: 34px; width: 34px; height: 34px; }
    .error-card p { margin: 2px 0 0; font-size: 14px; }

    /* ---------- skeleton ---------- */
    .skeleton { box-shadow: none; animation: none; }
    .skeleton::before { display: none; }
    .sk {
      border-radius: 10px;
      background: linear-gradient(90deg,
        rgba(128,128,128,0.15) 25%, rgba(128,128,128,0.28) 50%, rgba(128,128,128,0.15) 75%);
      background-size: 200% 100%;
      animation: shimmer 1.3s infinite linear;
    }
    .sk-icon { width: 48px; height: 48px; border-radius: 14px; }
    .sk-line { height: 14px; margin-top: 16px; width: 60%; }
    .sk-line.big { height: 30px; width: 80%; margin-top: 10px; }
    .sk-line.short { width: 40%; }

    /* ---------- dark mode ---------- */
    :host-context(.dark-theme) .stat,
    :host-context(.dark-theme) .range-card {
      background: #1e1e1e;
      border-color: rgba(255, 255, 255, 0.12);
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
    }
    :host-context(.dark-theme) .error-card {
      color: #ffcdd2; background: #3b1a1d; border-color: #5c2a2f;
    }
    :host-context(.dark-theme) .marker-dot { background: #1e1e1e; }

    /* ---------- animations ---------- */
    @keyframes rise {
      from { opacity: 0; transform: translateY(14px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes shimmer {
      from { background-position: 200% 0; }
      to   { background-position: -200% 0; }
    }

    /* ---------- small screens ---------- */
    @media (max-width: 700px) {
      .hero { padding: 26px 22px; }
      .hero h1 { font-size: 28px; }
      .hero-art { display: none; }
    }
  `]
})
export class HomeComponent implements OnInit {

  loading = true;
  error = false;

  total = 0;
  average = 0;
  averagePercent = 50;   // position of the "Avg" marker on the salary range bar
  highest: Employee | null = null;
  lowest: Employee | null = null;

  greeting = this.getGreeting();

  constructor(private employeeService: EmployeeService) {}

  private getGreeting(): string {
    const hour = new Date().getHours();
    if (hour < 12) { return 'Good morning'; }
    if (hour < 17) { return 'Good afternoon'; }
    return 'Good evening';
  }

  ngOnInit(): void {
    this.employeeService.getEmployees().subscribe({
      next: (employees) => {
        this.total = employees.length;

        if (employees.length > 0) {
          const sum = employees.reduce((acc, e) => acc + Number(e.salary), 0);
          this.average = sum / employees.length;
          this.highest = employees.reduce((a, b) => Number(b.salary) > Number(a.salary) ? b : a);
          this.lowest = employees.reduce((a, b) => Number(b.salary) < Number(a.salary) ? b : a);

          const min = Number(this.lowest.salary);
          const max = Number(this.highest.salary);
          this.averagePercent = max > min
            ? Math.min(100, Math.max(0, ((this.average - min) / (max - min)) * 100))
            : 50;
        }

        this.loading = false;
      },
      error: (err) => {
        console.error('Dashboard load error', err);
        this.loading = false;
        this.error = true;
      }
    });
  }
}