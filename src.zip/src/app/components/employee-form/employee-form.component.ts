import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  AbstractControl,
  FormBuilder,
  ReactiveFormsModule,
  ValidationErrors,
  Validators
} from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { EmployeeService } from '../../services/employee.service';
import { DEPARTMENTS, Employee, GENDERS } from '../../models/employee';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

/** Fails when the text is not empty but only contains spaces. */
function notOnlySpaces(control: AbstractControl): ValidationErrors | null {
  const value = control.value;
  return typeof value === 'string' && value.length > 0 && value.trim().length === 0
    ? { onlySpaces: true }
    : null;
}

const MAX_SALARY = 10000000;

@Component({
  selector: 'app-employee-form',
  standalone: true,
  providers: [provideNativeDateAdapter()],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatIconModule,
    MatDatepickerModule,
    MatSnackBarModule
  ],
  template: `
    <mat-card>
      <mat-card-header>
        <mat-card-title>
          {{ editMode ? 'Update Employee' : 'Add Employee' }}
        </mat-card-title>
      </mat-card-header>

      <mat-card-content>
        <a mat-button routerLink="/employees" class="back">
          <mat-icon>arrow_back</mat-icon>
          Back to list
        </a>

        <form [formGroup]="employeeForm" (ngSubmit)="saveEmployee()">

          <div class="grid">

            <!-- employeeId is NOT entered while creating.
                 Spring Boot/JPA generates it automatically. -->
            <mat-form-field appearance="outline" class="span-2" *ngIf="editMode">
              <mat-label>Employee ID</mat-label>
              <input matInput formControlName="employeeId" readonly>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Employee Name</mat-label>
              <input matInput formControlName="ename" maxlength="50"
                     placeholder="Enter employee name">
              <mat-hint align="end">{{ employeeForm.controls.ename.value?.length || 0 }}/50</mat-hint>

              <mat-error *ngIf="employeeForm.controls.ename.hasError('required')">
                Employee name is required
              </mat-error>
              <mat-error *ngIf="employeeForm.controls.ename.hasError('onlySpaces')">
                Name cannot contain only spaces
              </mat-error>
              <mat-error *ngIf="employeeForm.controls.ename.hasError('minlength')">
                Name must contain at least 2 characters
              </mat-error>
              <mat-error *ngIf="employeeForm.controls.ename.hasError('maxlength')">
                Name can have at most 50 characters
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Salary (₹)</mat-label>
              <input matInput type="number" formControlName="salary">

              <mat-error *ngIf="employeeForm.controls.salary.hasError('required')">
                Salary is required
              </mat-error>
              <mat-error *ngIf="employeeForm.controls.salary.hasError('min')">
                Salary must be greater than 0
              </mat-error>
              <mat-error *ngIf="employeeForm.controls.salary.hasError('max')">
                Salary cannot be more than {{ maxSalary | number }}
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Department</mat-label>
              <mat-select formControlName="department">
                <mat-option [value]="null">— None —</mat-option>
                <mat-option *ngFor="let d of departments" [value]="d">{{ d }}</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Job title</mat-label>
              <input matInput formControlName="jobTitle" maxlength="50">
              <mat-error *ngIf="employeeForm.controls.jobTitle.hasError('maxlength')">
                Job title can have at most 50 characters
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Gender</mat-label>
              <mat-select formControlName="gender">
                <mat-option [value]="null">— None —</mat-option>
                <mat-option *ngFor="let g of genders" [value]="g">{{ g }}</mat-option>
              </mat-select>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Joining date</mat-label>
              <input matInput [matDatepicker]="picker" formControlName="joiningDate"
                     readonly (click)="picker.open()" placeholder="Pick a date">
              <mat-datepicker-toggle matIconSuffix [for]="picker"></mat-datepicker-toggle>
              <mat-datepicker #picker></mat-datepicker>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Email</mat-label>
              <input matInput type="email" formControlName="email" maxlength="100">
              <mat-error *ngIf="employeeForm.controls.email.hasError('email')">
                Enter a valid email address
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline">
              <mat-label>Phone</mat-label>
              <input matInput formControlName="phone" maxlength="15">
              <mat-hint>Digits, spaces, + or - (7 to 15 characters)</mat-hint>
              <mat-error *ngIf="employeeForm.controls.phone.hasError('pattern')">
                Enter a valid phone number
              </mat-error>
            </mat-form-field>

          </div>

          <div class="buttons">
            <button
              mat-raised-button
              color="primary"
              type="submit"
              [disabled]="employeeForm.invalid || saving">
              {{ editMode ? 'Update' : 'Save' }}
            </button>

            <button mat-stroked-button type="button" (click)="resetForm()">
              <mat-icon>restart_alt</mat-icon>
              Reset
            </button>

            <a mat-raised-button routerLink="/employees">
              Cancel
            </a>
          </div>

        </form>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .back { margin: 8px 0 12px -8px; }
    .grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 6px 16px;
    }
    .span-2 { grid-column: span 2; }
    .buttons { display: flex; flex-wrap: wrap; gap: 12px; margin-top: 10px; }
    @media (max-width: 700px) {
      .grid { grid-template-columns: 1fr; }
      .span-2 { grid-column: span 1; }
    }
  `]
})
export class EmployeeFormComponent implements OnInit {

  editMode = false;
  employeeId = 0;
  saving = false;

  departments = DEPARTMENTS;
  genders = GENDERS;
  maxSalary = MAX_SALARY;

  /** The employee as loaded from the server (used by "Reset" in edit mode) */
  private original: Employee | null = null;

  employeeForm = this.fb.group({
    employeeId: [{ value: 0, disabled: true }],
    ename: ['', [
      Validators.required,
      notOnlySpaces,
      Validators.minLength(2),
      Validators.maxLength(50)
    ]],
    salary: [null as number | null, [
      Validators.required,
      Validators.min(0.01),
      Validators.max(MAX_SALARY)
    ]],
    department: [null as string | null],
    jobTitle: ['', [Validators.maxLength(50)]],
    gender: [null as string | null],
    email: ['', [Validators.email, Validators.maxLength(100)]],
    phone: ['', [Validators.pattern(/^[0-9+\-\s]{7,15}$/)]],
    joiningDate: [null as Date | null]
  });

  constructor(
    private fb: FormBuilder,
    private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.editMode = true;
      this.employeeId = Number(id);
      this.loadEmployee(this.employeeId);
    }
  }

  loadEmployee(id: number): void {
    this.employeeService.getEmployeeById(id).subscribe({
      next: (employee) => {
        this.original = employee;
        this.fillForm(employee);
      },
      error: (error) => {
        console.error('Error loading employee', error);
        this.snackBar.open('Employee not found.', 'Close', { duration: 5000 });
        this.router.navigate(['/employees']);
      }
    });
  }

  private fillForm(employee: Employee): void {
    this.employeeForm.reset({
      employeeId: employee.employeeId,
      ename: employee.ename,
      salary: employee.salary,
      department: employee.department ?? null,
      jobTitle: employee.jobTitle ?? '',
      gender: employee.gender ?? null,
      email: employee.email ?? '',
      phone: employee.phone ?? '',
      joiningDate: this.parseDate(employee.joiningDate)
    });
  }

  resetForm(): void {
    if (this.editMode && this.original) {
      this.fillForm(this.original);
    } else {
      this.employeeForm.reset({
        employeeId: 0,
        ename: '',
        salary: null,
        department: null,
        jobTitle: '',
        gender: null,
        email: '',
        phone: '',
        joiningDate: null
      });
    }
  }

  // "yyyy-MM-dd" <-> Date (built from local parts so the day never shifts)
  private parseDate(value?: string | null): Date | null {
    if (!value) {
      return null;
    }
    const [y, m, d] = value.split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  private formatDate(date: Date | null): string | null {
    if (!date) {
      return null;
    }
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const dd = String(date.getDate()).padStart(2, '0');
    return `${date.getFullYear()}-${mm}-${dd}`;
  }

  private emptyToNull(value: string | null | undefined): string | null {
    const trimmed = (value ?? '').trim();
    return trimmed === '' ? null : trimmed;
  }

  private errorText(error: any): string {
    if (error.status === 0) {
      return 'Cannot reach the server (is Spring Boot running on port 9020?)';
    }
    return error.error?.message || `Server returned ${error.status}: ${error.statusText}`;
  }

  saveEmployee(): void {
    if (this.employeeForm.invalid) {
      this.employeeForm.markAllAsTouched();
      return;
    }

    const f = this.employeeForm.controls;

    const data = {
      ename: (f.ename.value ?? '').trim(),
      salary: Number(f.salary.value ?? 0),
      department: f.department.value,
      jobTitle: this.emptyToNull(f.jobTitle.value),
      gender: f.gender.value,
      email: this.emptyToNull(f.email.value),
      phone: this.emptyToNull(f.phone.value),
      joiningDate: this.formatDate(f.joiningDate.value)
    };

    this.saving = true;

    if (!this.editMode) {
      // Do NOT send employeeId during CREATE.
      this.employeeService.addEmployee(data).subscribe({
        next: () => {
          this.snackBar.open('Employee added successfully.', 'OK', { duration: 3000 });
          this.router.navigate(['/employees']);
        },
        error: (error) => {
          console.error('Add error', error);
          this.saving = false;
          this.snackBar.open(this.errorText(error), 'Close', { duration: 7000 });
        }
      });

    } else {
      const updatedEmployee: Employee = {
        employeeId: this.employeeId,
        ...data
      };

      this.employeeService
        .updateEmployee(this.employeeId, updatedEmployee)
        .subscribe({
          next: () => {
            this.snackBar.open('Employee updated successfully.', 'OK', { duration: 3000 });
            this.router.navigate(['/employees']);
          },
          error: (error) => {
            console.error('Update error', error);
            this.saving = false;
            this.snackBar.open(this.errorText(error), 'Close', { duration: 7000 });
          }
        });
    }
  }
}