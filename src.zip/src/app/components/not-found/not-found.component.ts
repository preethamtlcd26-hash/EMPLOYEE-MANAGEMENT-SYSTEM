import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink, MatButtonModule, MatCardModule, MatIconModule],
  template: `
    <mat-card class="not-found">
      <mat-card-content>
        <h1>404</h1>
        <h2>Page not found</h2>
        <p>The page you are looking for does not exist or has been moved.</p>

        <a mat-raised-button color="primary" routerLink="/home">
          <mat-icon>home</mat-icon>
          Back to Home
        </a>
      </mat-card-content>
    </mat-card>
  `,
  styles: [`
    .not-found { text-align: center; padding: 40px 16px; }
    h1 { font-size: 72px; margin: 0; }
    h2 { margin: 4px 0 12px; }
    p { margin-bottom: 24px; }
  `]
})
export class NotFoundComponent {}