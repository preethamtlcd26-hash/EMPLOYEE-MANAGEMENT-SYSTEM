import { Component, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { Employee, yearsOfService } from '../../models/employee';

@Component({
  selector: 'app-employee-details-dialog',
  standalone: true,
  imports: [CommonModule, RouterLink, MatDialogModule, MatButtonModule],
  template: `
    <h2 mat-dialog-title>{{ employee.ename }}</h2>

    <mat-dialog-content>
      <dl class="details">
        <dt>Employee ID</dt>
        <dd>{{ employee.employeeId }}</dd>

        <dt>Department</dt>
        <dd>{{ employee.department || '—' }}</dd>

        <dt>Job title</dt>
        <dd>{{ employee.jobTitle || '—' }}</dd>

        <dt>Gender</dt>
        <dd>{{ employee.gender || '—' }}</dd>

        <dt>Email</dt>
        <dd>{{ employee.email || '—' }}</dd>

        <dt>Phone</dt>
        <dd>{{ employee.phone || '—' }}</dd>

        <dt>Salary</dt>
        <dd>{{ employee.salary | currency:'INR':'symbol':'1.2-2' }}</dd>

        <dt>Joining date</dt>
        <dd>{{ employee.joiningDate ? (employee.joiningDate | date:'dd MMM yyyy') : '—' }}</dd>

        <dt>Years of service</dt>
        <dd>{{ years }}</dd>

        <dt>Added on</dt>
        <dd>{{ employee.createdAt ? (employee.createdAt | date:'dd MMM yyyy, h:mm a') : '—' }}</dd>
      </dl>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button mat-dialog-close>Close</button>
      <a mat-raised-button
         color="primary"
         mat-dialog-close
         [routerLink]="['/employees/edit', employee.employeeId]">
        Edit
      </a>
    </mat-dialog-actions>
  `,
  styles: [`
    .details {
      display: grid;
      grid-template-columns: 140px 1fr;
      gap: 8px 16px;
      margin: 0;
    }
    dt { font-weight: 500; opacity: 0.7; }
    dd { margin: 0; word-break: break-word; }
  `]
})
export class EmployeeDetailsDialogComponent {
  years: string;

  constructor(@Inject(MAT_DIALOG_DATA) public employee: Employee) {
    this.years = yearsOfService(employee.joiningDate);
  }
}