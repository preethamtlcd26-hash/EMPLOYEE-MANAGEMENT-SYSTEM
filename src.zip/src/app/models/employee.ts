export interface Employee {
  employeeId: number;
  ename: string;
  salary: number;
  department?: string | null;
  jobTitle?: string | null;
  gender?: string | null;
  email?: string | null;
  phone?: string | null;
  joiningDate?: string | null;   
  createdAt?: string | null;     
}

export const DEPARTMENTS = ['HR', 'IT', 'Sales', 'Finance'];
export const GENDERS = ['Male', 'Female', 'Other'];

/** Turns a "yyyy-MM-dd" joining date into text like "2 yrs 3 mos". */
export function yearsOfService(joiningDate?: string | null): string {
  if (!joiningDate) {
    return '—';
  }

  const [y, m, d] = joiningDate.split('-').map(Number);
  const start = new Date(y, m - 1, d);
  const now = new Date();

  if (start > now) {
    return 'Not started yet';
  }

  let months = (now.getFullYear() - y) * 12 + (now.getMonth() - (m - 1));
  if (now.getDate() < d) {
    months--;
  }
  if (months < 0) {
    months = 0;
  }

  const years = Math.floor(months / 12);
  const rest = months % 12;
  const parts: string[] = [];

  if (years > 0) {
    parts.push(years + (years === 1 ? ' yr' : ' yrs'));
  }
  if (rest > 0) {
    parts.push(rest + (rest === 1 ? ' mo' : ' mos'));
  }

  return parts.length ? parts.join(' ') : 'Less than a month';
}