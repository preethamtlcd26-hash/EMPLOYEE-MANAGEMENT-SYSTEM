import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadComponent: () =>
      import('./components/home/home.component').then(m => m.HomeComponent)
  },
  {
    path: 'employees',
    loadComponent: () =>
      import('./components/employee-list/employee-list.component')
        .then(m => m.EmployeeListComponent)
  },
  {
    path: 'employees/add',
    loadComponent: () =>
      import('./components/employee-form/employee-form.component')
        .then(m => m.EmployeeFormComponent)
  },
  {
    path: 'employees/edit/:id',
    loadComponent: () =>
      import('./components/employee-form/employee-form.component')
        .then(m => m.EmployeeFormComponent)
  },
  {
    path: '**',
    loadComponent: () =>
      import('./components/not-found/not-found.component')
        .then(m => m.NotFoundComponent)
  }
];