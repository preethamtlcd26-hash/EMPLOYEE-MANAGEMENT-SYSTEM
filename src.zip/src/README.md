# Angular 17 Employee CRUD - src folder

This source is designed for Angular 17 standalone components.

## Spring Boot model

```java
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private long employeeId;

private String ename;
private float salary;
```

## Expected REST API

The Angular service currently expects:

GET    http://localhost:8080/api/employees
GET    http://localhost:8080/api/employees/{id}
POST   http://localhost:8080/api/employees
PUT    http://localhost:8080/api/employees/{id}
DELETE http://localhost:8080/api/employees/{id}

If your Spring Boot controller uses another URL, change only:

`src/app/services/employee.service.ts`

## Important employeeId rule

During CREATE, Angular sends only:

```json
{
  "ename": "Ravi",
  "salary": 50000
}
```

Spring Boot/JPA generates employeeId.

During UPDATE, Angular sends:

```json
{
  "employeeId": 1,
  "ename": "Ravi",
  "salary": 55000
}
```

## Install/use

1. Create an Angular 17 project if you do not already have one.
2. Install Angular Material:
   `ng add @angular/material`
3. Replace the project's `src` folder with this `src` folder.
4. Run:
   `ng serve`
5. Open:
   `http://localhost:4200`

## Node 26 note

The source code itself does not depend on Node-specific APIs. Use the Angular CLI/package versions compatible with your installed Angular 17 project. If your existing Angular 17 project builds successfully with your Node 26 setup, this source can be placed into its `src` folder.
