package com.example.employee;

public class DuplicateEmailException extends RuntimeException {

    public DuplicateEmailException(String email) {
        super("An employee with the email " + email + " already exists");
    }
}