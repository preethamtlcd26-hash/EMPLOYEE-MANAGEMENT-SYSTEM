package com.example.employee;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long employeeId;

    @NotBlank(message = "Name is required")
    @Size(max = 50, message = "Name can have at most 50 characters")
    private String ename;

    @DecimalMin(value = "0.0", message = "Salary cannot be negative")
    @DecimalMax(value = "10000000", message = "Salary cannot be more than 10,000,000")
    private float salary;

    @Size(max = 50, message = "Department can have at most 50 characters")
    private String department;

    @Size(max = 50, message = "Job title can have at most 50 characters")
    private String jobTitle;

    @Size(max = 20, message = "Gender can have at most 20 characters")
    private String gender;

    @Email(message = "Enter a valid email address")
    @Size(max = 100, message = "Email can have at most 100 characters")
    private String email;

    @Pattern(regexp = "^[0-9+\\-\\s]{7,15}$", message = "Enter a valid phone number")
    private String phone;

    private LocalDate joiningDate;

    // Set automatically when the employee is first saved
    private LocalDateTime createdAt;

    public Employee() {}

    @PrePersist
    void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public long getEmployeeId() { return employeeId; }
    public void setEmployeeId(long employeeId) { this.employeeId = employeeId; }

    public String getEname() { return ename; }
    public void setEname(String ename) { this.ename = ename; }

    public float getSalary() { return salary; }
    public void setSalary(float salary) { this.salary = salary; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = jobTitle; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public LocalDate getJoiningDate() { return joiningDate; }
    public void setJoiningDate(LocalDate joiningDate) { this.joiningDate = joiningDate; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}