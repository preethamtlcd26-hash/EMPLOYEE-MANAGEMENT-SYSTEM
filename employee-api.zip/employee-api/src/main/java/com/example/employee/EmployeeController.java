package com.example.employee;

import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class EmployeeController {

    private final EmployeeRepository repository;

    public EmployeeController(EmployeeRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/getEmployees")
    public List<Employee> getEmployees() {
        return repository.findAll();
    }

    @GetMapping("/getEmployeeById/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable long id) {
        return repository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/add")
    public Employee add(@Valid @RequestBody Employee employee) {
        tidy(employee);
        checkDuplicateEmail(employee.getEmail(), null);

        employee.setEmployeeId(0);   // let the database generate the id
        employee.setCreatedAt(null); // set automatically when saved
        return repository.save(employee);
    }

    @PutMapping("/updateEmployeeById/{id}")
    public ResponseEntity<Employee> update(@PathVariable long id,
                                           @Valid @RequestBody Employee employee) {
        return repository.findById(id).map(existing -> {
            tidy(employee);
            checkDuplicateEmail(employee.getEmail(), id);

            existing.setEname(employee.getEname());
            existing.setSalary(employee.getSalary());
            existing.setDepartment(employee.getDepartment());
            existing.setJobTitle(employee.getJobTitle());
            existing.setGender(employee.getGender());
            existing.setEmail(employee.getEmail());
            existing.setPhone(employee.getPhone());
            existing.setJoiningDate(employee.getJoiningDate());
            return ResponseEntity.ok(repository.save(existing));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/deleteEmployeeById/{id}")
    public ResponseEntity<Void> delete(@PathVariable long id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Bulk delete: the body is a JSON list of ids, e.g. [1, 2, 3]
    @PostMapping("/deleteEmployees")
    public ResponseEntity<Void> deleteMany(@RequestBody List<Long> ids) {
        repository.deleteAllById(ids);
        return ResponseEntity.noContent().build();
    }

    // ---------- helpers ----------

    /** Trims text and turns empty strings into null. */
    private void tidy(Employee employee) {
        employee.setEname(blankToNull(employee.getEname()));
        employee.setDepartment(blankToNull(employee.getDepartment()));
        employee.setJobTitle(blankToNull(employee.getJobTitle()));
        employee.setGender(blankToNull(employee.getGender()));
        employee.setEmail(blankToNull(employee.getEmail()));
        employee.setPhone(blankToNull(employee.getPhone()));
    }

    private String blankToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    /** Rejects an email that already belongs to a different employee. */
    private void checkDuplicateEmail(String email, Long currentId) {
        if (email == null) {
            return;
        }
        repository.findByEmailIgnoreCase(email).ifPresent(other -> {
            if (currentId == null || other.getEmployeeId() != currentId) {
                throw new DuplicateEmailException(email);
            }
        });
    }
}