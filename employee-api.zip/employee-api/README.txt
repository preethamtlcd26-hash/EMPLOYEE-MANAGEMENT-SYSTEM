Employee API (Spring Boot 3, Java 17, H2 database)

RUN:
  mvn spring-boot:run
Then check: http://localhost:9020/getEmployees  (should show [])

Needs: JDK 17+ and Maven (or open the folder in IntelliJ / VS Code / Eclipse
and run EmployeeApiApplication).
